# presets_loader.py (minimal, Python 3.11+)
from typing import Any, Dict, Mapping
from types import SimpleNamespace
import os
import tomllib  # stdlib TOML parser (Py 3.11+)

# Defaults (preset can override)
DEFAULT_SYNTH: Dict[str, Any] = {
    # Dataset/paths - fixed
    "input_patch_root": "results/extracted_patches",
    "input_bg_root": "results/extracted_backgrounds",

    # Output
    "out_root": "results/image_generation",

    # -------------- default values -------------------------------
    "pjt_name": "please_write_pjt_name",
    "pxum": 5.0,                     # pixels per micron
    "intended_density": 200.0,       # cells per (100um)^2

    "seed": 100,
    "is_cv": 0,

    # Simulation
    "box_size": (200, 200),
    "fps": 52.0,
    "velocity_pxps": 50.0,
    "D_T": 1.0,
    "D_R": 1.0,
    "omega": 0.0,                    # angular velocity for chiral rotational diffusion.

    "n_step": 10,
    "skip_interval": 1,
    "draw_index": False,

    # --- for visualization
    "draw_scalebar": False,

    # --- CODES (will be filled in preset) ---
    "patch_code_to_use": None,
    "bg_code_to_use": None,
}



def _read_toml(path: str) -> Dict[str, Any]:
    """Read a TOML file into a dict."""
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    with open(path, "rb") as f:  # tomllib expects binary mode
        return tomllib.load(f) or {}

# def load_data_preset(file_path: str, name: str) -> Dict[str, Any]:
#     """Return DATA[name] dict from file_path (expects [DATA.<name>])."""
#     root = _read_toml(file_path)
#     d = root["DATA"][name]
#     # minimal coercion
#     return {
#         "px_per_um": float(d["px_per_um"]),
#         "fps": float(d["fps"]),
#         "memo": d.get("memo"),
#     }

def _get_section(root: Mapping[str, Any], *path: str) -> Mapping[str, Any]:
    cur: Any = root
    for p in path:
        if not isinstance(cur, Mapping) or p not in cur:
            raise KeyError(f"Missing section [{'.'.join(path)}] in TOML")
        cur = cur[p]
    if not isinstance(cur, Mapping):
        raise TypeError(f"Section [{'.'.join(path)}] must be a table")
    return cur

def load_synth_preset(file_path: str, name: str) -> Dict[str, Any]:
    """Return SYNTH[name] dict from file_path (expects [SYNTH.<name>])."""
    root = _read_toml(file_path)
    return dict(_get_section(root, "SYNTH", name))  # overrides only


def make_synth(synth_cfg: Dict[str, Any], _data_cfg: Dict[str, Any] | None = None) -> SimpleNamespace:
    """
    Defaults + overrides 
    """
    c: Dict[str, Any] = {**DEFAULT_SYNTH, **(synth_cfg or {})}
    # 가벼운 형변환(있을 때만)
    # if "alpha" in c: 
    #     try: c["alpha"] = float(c["alpha"])
    #     except Exception: pass
    return SimpleNamespace(**c)