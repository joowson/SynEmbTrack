import os
import importlib
from synembtrack.synth.composit.configs.base import Config
from synembtrack.synth.composit.runner import run_once

from synembtrack._paths import get_raw_data_dir, get_results_dir

# Optional: local overrides (create your own module if needed)
# try: from src.image_generation.configs.local import LOCAL as _LOCAL  # type: ignore
# except Exception: _LOCAL = {}
# def apply_overrides(cfg: Config, d: dict): 
#     for k, v in d.items():
#         if hasattr(cfg, k): 
#             setattr(cfg, k, v)



if __name__ == "__main__":
    
    
    
    raw_data_code = "demo_2Dsuspension_25C" 
    
    synth_img_code = "synthSet_VSreal"   

    
    ### --- Load preset
    preset_module = importlib.import_module(
        f"..configs.configs_composit.{synth_img_code}"
    )
    cfg: Config = preset_module.get_config()
    
    cfg.pjt_name = synth_img_code
    cfg.input_patch_root = os.path.join(get_results_dir(), raw_data_code, 'imgGen')
    cfg.input_bg_root    = os.path.join(get_results_dir(), raw_data_code, "imgGen") 
    cfg.out_root         = os.path.join(get_results_dir(), raw_data_code, "imgGen")
    
    ### --- Local override (optional)
    # apply_overrides(cfg, _LOCAL)
    
    
    ### --- Run
    # One-off quick tweaks can go here:
    # cfg.n_step = 100
    run_once(cfg)
