from synembtrack.synth.composit.configs.base import Config

def get_config() -> Config:
    cfg = Config()



    cfg.pxum = 2.2  # <-- CHANGE THIS by following raw_data's experimental setting.
    cfg.pjt_name = "synthSet_VSreal"  ### same as the filename of preset

    cfg.patch_code_to_use = 'patchSet_0001'
    cfg.bg_code_to_use    = 'bgSet_0001'


    cfg.draw_scalebar = False
    
    # -----------------------------------------

    cfg.seed = 14
    cfg.is_cv = 1

    ### ----- Simulation System
    cfg.n_step = 10
    cfg.skip_interval = 1
    cfg.box_size = (200, 200)

    cfg.intended_density = 200.0   ### cells / 10^4 micron^2


    ### ----- dynamics

    # Length unit: pixel, time unit: sec
    # * Length must be converted with the pxum value to match SI units.
    # * For training data used in segmentation, no major modification is necessary.


    cfg.particle_velocity = 50      ## unit: px / sec
    cfg.D_T = 1                     ## unit: px^2 /sec
    cfg.D_R = 1                     ## unit: px^2 /sec
    cfg.fps = 52                    ## unit: 1/sec
    cfg.dt = 1.0/cfg.fps            ## unit: sec




    # Typical input locations under project structure
    # Put your extracted patches (patch_body_*, patch_bdry_*) under a folder:
    #   img_input/patches/PATCHCODE_xxx/patch/
    # and set that path here:
    # cfg.patch_dir = "img_input/patches/PATCHCODE_xxx/patch"
    # Background frames under:
    #   img_input/backgrounds/
    # cfg.bg_glob   = "img_input/backgrounds/**/*.tif"
    return cfg
